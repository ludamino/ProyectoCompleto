<?php return array (
  'liwi-act-alumno' => 'App\\Http\\Livewire\\LiwiActAlumno',
  'liwi-act-contenido' => 'App\\Http\\Livewire\\LiwiActContenido',
  'liwi-actividades' => 'App\\Http\\Livewire\\LiwiActividades',
  'liwi-alumno-cursos' => 'App\\Http\\Livewire\\LiwiAlumnoCursos',
  'liwi-asignar-actividad' => 'App\\Http\\Livewire\\LiwiAsignarActividad',
  'liwi-contestar-actividad' => 'App\\Http\\Livewire\\LiwiContestarActividad',
  'liwi-materias' => 'App\\Http\\Livewire\\LiwiMaterias',
  'liwi-tipo-usuario' => 'App\\Http\\Livewire\\LiwiTipoUsuario',
  'liwi-usuario' => 'App\\Http\\Livewire\\LiwiUsuario',
  'liwi-ver-act-maestro' => 'App\\Http\\Livewire\\LiwiVerActMaestro',
);