<div class="container-fluid"> 
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alarmas-info','data' => []]); ?>
<?php $component->withName('alarmas-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <div class="items-center">
        <br>
        <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-center">
                <li class="breadcrumb-item"><a href="<?php echo e(route('mis-cursos')); ?>">Cursos</a></li>
                <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('alumno-actividades',$this->id_materia)); ?>">Actividades</a></li>
                <li class="breadcrumb-item active" aria-current="page">Contestar</li>
            </ol>
        </nav>
        <br>

    </div>

    <div>
        <?php if(session()->has('prueba')): ?>
        <div class="alert alert-success">
            <?php echo e(session('prueba')); ?>

        </div>
        <?php endif; ?>

        <br><br>

        <?php if(session()->has('pruebar')): ?>
        <div class="alert alert-success">
            <?php echo e(session('pruebar')); ?>

        </div>
        <?php endif; ?>
    </div>

    <div class="container-fluid">
        <div class="row align-items-start">
            <div class="col-4 text-center">

                <?php $__currentLoopData = $datos_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="ratio ratio-16x9">
                    <iframe width="1199" height="674" src="<?php echo e($documentos->link_video); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                <br>
                <?php if($documentos->Documento == null): ?>
                <?php else: ?>
                <a href="<?php echo e($documentos->Documento); ?>" target="_blanck" class="btn btn-outline-info">Ver Documento</a>
                <?php endif; ?>


                <?php break; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <br><br>
            </div>
            <div class="col border border-5">

                <br>


                <?php $__currentLoopData = $datos_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h1 class="text-center"> <?php echo e($nombre->nombre_actividad); ?></h1>
                <?php break; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <br>


                <?php $__currentLoopData = $asignar_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado_actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($estado_actividad->estado == 'Terminado'): ?>








                <?php $__currentLoopData = $respuestas_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solo_respuestas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($solo_respuestas->tipo_campo == 'text'): ?>
                <div class="mt-4">
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" value="<?php echo e($solo_respuestas->respuesta); ?>" disabled>
                        <label><?php echo e($solo_respuestas->pregunta); ?></label>
                    </div>

                </div>

                <?php else: ?>
                <div class="mt-4">
                    <div class="form-floating">
                        <textarea class="form-control" style="height: 100px" disabled><?php echo e($solo_respuestas->respuesta); ?> </textarea>
                        <label><?php echo e($solo_respuestas->pregunta); ?></label>
                    </div>


                </div>
                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




































                <?php else: ?>

                <?php $__currentLoopData = $datos_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $preguntas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($preguntas->tipo_campo == 'text'): ?>
                <div class="mt-4">
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" wire:model="respuesta.<?php echo e($loop->index); ?>" required>
                        <label><?php echo e($preguntas->pregunta); ?></label>
                    </div>

                </div>

                <?php else: ?>
                <div class="mt-4">
                    <div class="form-floating">
                        <textarea class="form-control" wire:model="respuesta.<?php echo e($loop->index); ?>" style="height: 100px" required></textarea>
                        <label><?php echo e($preguntas->pregunta); ?></label>
                    </div>


                </div>
                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $solo_id_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iddds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                $this->id_cont = $this->id_cont . '-' . $iddds->id;



                $errorid++;
                $this->reglaarray['respuesta.' . $errorid] = 'required';
                ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="mt-4">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.danger-button','data' => ['class' => 'ml-2','wire:click' => 'insertar','wire:loading.attr' => 'disabled']]); ?>
<?php $component->withName('jet-danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-2','wire:click' => 'insertar','wire:loading.attr' => 'disabled']); ?>
                        <?php echo e(__('Insertar')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>


                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <br>
            </div>
        </div>
    </div>


</div><?php /**PATH /home1/proye324/ludamino.proyectostics.com/resources/views/livewire/liwi-contestar-actividad.blade.php ENDPATH**/ ?>