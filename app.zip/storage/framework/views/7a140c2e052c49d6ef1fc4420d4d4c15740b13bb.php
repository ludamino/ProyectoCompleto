<a href="/">
<center><img class="img-fluid" src="https://proyectostics.com/wp-content/uploads/2022/03/logo_transparent-e1648418375769.png" width="15%" height="100%" alt=""></center>
</a>
<?php /**PATH C:\xampp\htdocs\ludamino\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>