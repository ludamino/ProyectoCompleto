<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="16pt" height="16pt" x="0" y="0" viewBox="0 0 367.3877 351.3397" style="enable-background:new 0 0 512 512" xml:space="preserve" class="">
    <g>
        <g xmlns="http://www.w3.org/2000/svg" id="Layer_2" data-name="Layer 2">
            <g id="Layer_1-2" data-name="Layer 1">
                <path d="m345.196 49.962h11.363v10.829h-11.363z" fill="#058789" data-original="#058789"></path>
                <path d="m303.703 37.633h41.493v159.641h-41.493z" fill="#4d4d4d" data-original="#4d4d4d"></path>
                <path d="m300.379 197.273h48.194v107.804h-48.194z" fill="#e3a72f" data-original="#e3a72f" class=""></path>
                <path d="m308.046 21.229h32.805v15.975h-32.805z" fill="#edf3f3" data-original="#edf3f3" class=""></path>
                <path d="m345.8376 12.6518v8.5776h-42.7231v-8.5776a7.2529 7.2529 0 0 1 7.2374-7.29h28.2481a7.2529 7.2529 0 0 1 7.2376 7.29z" fill="#058789" data-original="#058789"></path>
                <path d="m345.249 305.077-7.023 15.545-6.861 15.333-6.915 15.385-6.916-15.385-6.863-15.333-7.02-15.545z" fill="#4d4d4d" data-original="#4d4d4d"></path>
                <path d="m338.226 320.622-6.861 15.333-6.915 15.385-6.916-15.385-6.863-15.333z" fill="#edf3f3" data-original="#edf3f3" class=""></path>
                <path d="m331.365 335.955-6.915 15.385-6.916-15.385z" fill="#058789" data-original="#058789"></path>
                <path d="m367.3877 37.6327v82.9832a10.7758 10.7758 0 0 1 -10.7737 10.775v-93.7582z" fill="#4d4d4d" data-original="#4d4d4d"></path>
                <path d="m0 329.1918v-266.3647l62.8264-62.8271h173.1187a21.8748 21.8748 0 0 1 21.8749 21.8748v307.317a21.8748 21.8748 0 0 1 -21.8748 21.8748h-214.0704a21.8748 21.8748 0 0 1 -21.8748-21.8748z" fill="#edf3f3" data-original="#edf3f3" class=""></path>
                <g fill="#cdd1d1">
                    <path d="m62.8264 0v40.9523a21.8748 21.8748 0 0 1 -21.8748 21.8748h-40.9516z" fill="#cdd1d1" data-original="#cdd1d1" class=""></path>
                    <path d="m106.134 56.263h120.198v6.564h-120.198z" fill="#cdd1d1" data-original="#cdd1d1" class=""></path>
                    <path d="m106.134 33.739h120.198v6.564h-120.198z" fill="#cdd1d1" data-original="#cdd1d1" class=""></path>
                    <path d="m29.412 302.869h200.35v6.564h-200.35z" fill="#cdd1d1" data-original="#cdd1d1" class=""></path>
                    <path d="m29.412 286.567h200.35v6.564h-200.35z" fill="#cdd1d1" data-original="#cdd1d1" class=""></path>
                    <path d="m29.412 255.685h200.35v6.564h-200.35z" fill="#cdd1d1" data-original="#cdd1d1" class=""></path>
                    <path d="m29.412 239.383h200.35v6.564h-200.35z" fill="#cdd1d1" data-original="#cdd1d1" class=""></path>
                    <path d="m29.412 208.501h200.35v6.564h-200.35z" fill="#cdd1d1" data-original="#cdd1d1" class=""></path>
                    <path d="m29.412 192.199h200.35v6.564h-200.35z" fill="#cdd1d1" data-original="#cdd1d1" class=""></path>
                    <path d="m29.412 161.317h200.35v6.564h-200.35z" fill="#cdd1d1" data-original="#cdd1d1" class=""></path>
                    <path d="m29.412 145.015h200.35v6.564h-200.35z" fill="#cdd1d1" data-original="#cdd1d1" class=""></path>
                    <path d="m29.412 114.133h200.35v6.564h-200.35z" fill="#cdd1d1" data-original="#cdd1d1" class=""></path>
                    <path d="m29.412 97.831h200.35v6.564h-200.35z" fill="#cdd1d1" data-original="#cdd1d1" class=""></path>
                </g>
            </g>
        </g>
    </g>
</svg><?php /**PATH /home1/proye324/ludamino.proyectostics.com/resources/views/components/icon-revisar.blade.php ENDPATH**/ ?>