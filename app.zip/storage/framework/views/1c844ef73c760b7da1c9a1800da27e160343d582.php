<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="50pt" height="50pt" x="0" y="0" viewBox="0 0 25.643 25.643" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g>
<g xmlns="http://www.w3.org/2000/svg">
	<path  d="M24.046,14.254c-0.077,0.375-0.333,0.725-0.804,0.612c-1.695-0.401-4.351-0.521-5.924-0.14   c-0.578,0.14-0.848-0.112-1.065-0.803c-0.541-1.717-1.395-3.787-1.211-6.439c0.411-5.941,2.864-7.586,4.712-7.479   S26.351,3.049,24.046,14.254z M16.444,17.799c0,0-0.331,1.031-0.517,2.71c-0.308,2.777,0.289,4.704,3.001,5.094   c2.288,0.33,3.757-1.39,4.063-4.167c0.185-1.678,0.201-2.749,0.201-2.749L16.444,17.799z" fill="#030104" data-original="#030104"></path>
	<path  d="M5.89,0.005c1.848-0.106,4.301,1.538,4.712,7.479c0.184,2.652-0.67,4.723-1.211,6.439   c-0.218,0.69-0.487,0.942-1.065,0.803c-1.573-0.381-4.229-0.262-5.924,0.14c-0.471,0.112-0.727-0.237-0.804-0.612   C-0.707,3.049,4.043,0.112,5.89,0.005z M2.451,18.687c0,0,0.017,1.071,0.201,2.749c0.307,2.777,1.775,4.497,4.063,4.167   c2.712-0.39,3.309-2.316,3.001-5.094c-0.186-1.679-0.517-2.71-0.517-2.71L2.451,18.687z" fill="#030104" data-original="#030104"></path>
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
<g xmlns="http://www.w3.org/2000/svg">
</g>
</g></svg><?php /**PATH /home1/proye324/ludamino.proyectostics.com/resources/views/components/icon-pasos.blade.php ENDPATH**/ ?>