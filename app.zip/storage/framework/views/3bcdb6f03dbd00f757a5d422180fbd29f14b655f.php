<div class="p-6"> 

<div class="items-center">

<nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="/">Panel</a></li>
        <li class="breadcrumb-item"><a>Cursos</a></li>
    </ol>
</nav>

</div>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alarmas-info','data' => []]); ?>
<?php $component->withName('alarmas-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php if($asignar_data->COUNT()): ?>
        <?php $__currentLoopData = $asignar_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card h-100 text-center">
                <div class="card-body">
                    <h3 class="card-title"><span class="badge bg-info text-dark"><?php echo e($asignar->materia); ?></span></h3>
                    <br>
                    <br>
                    <a href="<?php echo e(route('alumno-actividades',$asignar->id_materia)); ?>" class="btn btn-success">Ver actividades del curso</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>

        <div class="col">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title"><span class="badge bg-warning text-dark"> No tienes actividades asignadas</span></h5>
                    <br>
                    <p class="card-text"></p>
                    <br>
                </div>
                <div class="card-footer">
                </div>
            </div>
        </div>

        <?php endif; ?>
    </div>
    
</div><?php /**PATH C:\xampp\htdocs\ludamino\resources\views/livewire/liwi-alumno-cursos.blade.php ENDPATH**/ ?>