<a href="/">
<center><img class="img-fluid" src="https://proyectostics.com/wp-content/uploads/2022/03/logo_transparent-e1648418375769.png" width="15%" height="100%" alt=""></center>
</a>
<?php /**PATH /home1/proye324/ludamino.proyectostics.com/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>