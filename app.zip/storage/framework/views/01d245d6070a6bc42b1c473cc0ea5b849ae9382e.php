<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" width="50=pt" height="50pt" x="0" y="0" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512" xml:space="preserve" class="">
    <g>
        <g xmlns="http://www.w3.org/2000/svg">
            <circle cx="256" cy="256" fill="#6e83b7" r="246" data-original="#6e83b7" class=""></circle>
            <path d="m363.994 318.971c-28.941-8.297-67.294-12.866-107.994-12.866s-79.053 4.568-107.994 12.865c-32.06 9.19-49.006 22.032-49.006 37.135 0 28.988 62.523 45.199 125.82 49.071l-15.77 15.769 9.9 9.9 31.949-31.95-31.949-31.95-9.9 9.9 14.231 14.23c-71.206-4.532-110.281-22.818-110.281-34.97 0-5.783 10.179-15.454 38.864-23.678 27.721-7.946 64.704-12.322 104.136-12.322s76.415 4.376 104.136 12.322c28.685 8.224 38.864 17.895 38.864 23.678 0 13.136-45.652 33.44-128.199 35.793l.398 13.994c68.296-1.946 141.801-18.356 141.801-49.787 0-15.103-16.946-27.945-49.006-37.134z" fill="#80d6fb" data-original="#80d6fb"></path>
            <g>
                <path d="m256 99.501c-49.71 0-90 40.29-90 90 0 7.95 1.03 15.66 2.97 23 1.32 5.05 3.08 9.92 5.23 14.58 2.04 4.45 81.8 145.42 81.8 145.42s79.76-140.97 81.8-145.42c2.15-4.66 3.91-9.53 5.23-14.58 1.94-7.34 2.97-15.05 2.97-23 0-49.71-40.29-90-90-90z" fill="#edeff1" data-original="#edeff1" class=""></path>
                <circle cx="256" cy="189.501" fill="#80d6fb" r="45" data-original="#80d6fb"></circle>
            </g>
        </g>
    </g>
</svg><?php /**PATH /home1/proye324/ludamino.proyectostics.com/resources/views/components/icon-recorrido.blade.php ENDPATH**/ ?>