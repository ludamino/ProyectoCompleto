<div class="p-6"> 

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alarmas-info','data' => []]); ?>
<?php $component->withName('alarmas-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <div class="items-center">

        <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('mis-cursos')); ?>">Cursos</a></li>
                <li class="breadcrumb-item active" aria-current="page">Actividades</li>
            </ol>
        </nav>

    </div>

    
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php if($asignar_data->COUNT()): ?>
        <?php $__currentLoopData = $asignar_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="card h-100 text-center">

                <div class="card-body">

                    <h5 class="card-title"><span class="badge bg-info text-dark"><?php echo e($asignar->materia); ?></span></h5>
                    <br>
                    <p class="card-text"><strong>Actividad </strong>: <?php echo e($asignar->nombre_actividad); ?></p>
                    <br>
                    <?php if($asignar->estado == 'Pendiente'): ?>
                    <p class="card-text"><strong>Estado </strong>: <span class="badge bg-warning text-dark"><?php echo e($asignar->estado); ?></span></p>
                    <?php else: ?>
                    <p class="card-text"><strong>Estado </strong>: <span class="badge bg-success "> <?php echo e($asignar->estado); ?></span></p>
                    <?php endif; ?>
                    <br>
                    
                    <a href="<?php echo e(route('contesta-actividad',$asignar->clv_actividad .'-' . $asignar->id_asignar .'-' . $asignar->clv_materia)); ?>" class="btn btn-success">Ver actividad</a>
                    

                </div>
                <div class="card-footer">
                    Fecha de entrega : <span class="badge rounded-pill bg-dark"><?php echo e($asignar->fecha_entrega); ?></span>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>

        <div class="col">
            <div class="card h-100">

                <div class="card-body">
                    <h5 class="card-title"><span class="badge bg-warning text-dark"> No tienes actividades asignadas</span></h5>
                    <br>
                    <p class="card-text"></p>
                    <br>

                </div>
                <div class="card-footer">

                </div>
            </div>
        </div>

        <?php endif; ?>
    </div>
    
</div><?php /**PATH C:\xampp\htdocs\ludamino\resources\views/livewire/liwi-act-alumno.blade.php ENDPATH**/ ?>