

<?php $__env->startSection('code', '403 🚫'); ?>

<?php $__env->startSection('title', __('No tienes permiso')); ?>

<?php $__env->startSection('image'); ?>

<div style="background-image: url('https://proyectostics.com/wp-content/uploads/2022/03/alberta-ga5170c449_1920.jpg');" class="absolute pin bg-no-repeat md:bg-left lg:bg-center">
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('message', __('No tienes permiso para ver esta pagina')); ?>
<?php echo $__env->make('errors::illustrated-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ludamino\resources\views/errors/403.blade.php ENDPATH**/ ?>