<div class="p-6"> 


    <h2 class="text-center">Catalogo Materias </h2>
    <br><br>

    <div class="container">
        <div class="row">
            <div class="col">
                <br>
                <div class="card" style="width: 20rem;">
                    <img src="https://proyectostics.com/wp-content/uploads/2022/03/board-gec14f8b03_1920.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-text text-center"> <span class="badge bg-primary">Algebra</span></h5>
                    </div>
                </div>
            </div>
            <div class="col">
                <br>
                <div class="card" style="width: 20rem;">
                    <img src="https://proyectostics.com/wp-content/uploads/2022/03/mathematics-ga53603512_1920.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-text text-center"><span class=" card-text badge bg-primary">Limites</span></h5>
                    </div>
                </div>
            </div>
            <div class="col">
                <br>
                <div class="card" style="width: 20rem;">
                    <img src="https://proyectostics.com/wp-content/uploads/2022/03/pi-g3e8412a26_1920.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-text text-center"><span class="badge bg-primary">Integrales</span></h5>
                    </div>
                </div>
            </div>
            <div class="col">
                <br>
                <div class="card" style="width: 20rem;">
                    <img src="https://proyectostics.com/Ludamino/img/triples.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-text text-center"><span class="badge bg-primary">Integrales Triples</span></h5>
                    </div>
                </div>
            </div>
            <div class="col">
                <br>
                <div class="card" style="width: 20rem;">
                    <img src="https://proyectostics.com/Ludamino/img/derivadasparciales.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-text text-center"><span class="badge bg-primary">Derivadas Parciales</span></h5>
                    </div>
                </div>
            </div>
            <div class="col">
                <br>
                <div class="card" style="width: 20rem;">
                    <img src="https://proyectostics.com/Ludamino/img/triples.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-text text-center"><span class="badge bg-primary">Vectores</span></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>




</div><?php /**PATH C:\xampp\htdocs\ludamino\resources\views/components/vista-alumno.blade.php ENDPATH**/ ?>