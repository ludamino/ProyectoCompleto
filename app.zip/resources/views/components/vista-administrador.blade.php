<div class="p-6"> {{-- INICIO Cuerpo INICIO  --}}


    <h3>Modulos del administrador</h3>

    <br><br>

    <div class="container">
        <div class="row ">
            <div class="col">
                <center>
                    <button class="btn btn-outline-success">Usuario</button>
                </center>
                <br>
                Este modulo permitira el acceso de los usuarios el sistema, el admnistrador tiene la funcion de aceptar o rechazar a los usuarios.
            </div>
            <div class="col">
                <center>
                    <button class="btn btn-outline-success">Tipo de usuario</button>
                </center>
                <br>

                Este modulo permite agrewgar tipos de usuario al sistema.
            </div>
            <div class="col ">
                <center>
                    <button class="btn btn-outline-success">Materias</button>
                </center>
                <br>

                Este modulo permite agregar las materias de las cuales los maestros tienen permitido crear actividades.
            </div>
        </div>


    </div>


</div>{{-- FIN  Cuerpo FIN --}}